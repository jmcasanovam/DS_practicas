require "test_helper"

class MilitarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
