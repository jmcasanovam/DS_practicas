package com.example.militares

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
