class Militar < ApplicationRecord
end
